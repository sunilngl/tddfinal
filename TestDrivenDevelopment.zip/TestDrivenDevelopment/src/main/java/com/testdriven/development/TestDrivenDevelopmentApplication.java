package com.testdriven.development;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestDrivenDevelopmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestDrivenDevelopmentApplication.class, args);
	}

}
