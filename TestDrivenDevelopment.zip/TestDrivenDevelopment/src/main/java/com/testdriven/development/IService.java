package com.testdriven.development;

import java.util.List;

public interface IService {

	
	public ModelDTO addModelData(ModelDTO modelDto);
	
	public ModelDTO getModelData(Integer modelId);
	
	public List<ModelDTO> getAllModelData();
	
	public String deleteModelData(Integer modelId);
	
	public ModelDTO updateModelData(ModelDTO modelDto);
	
}
