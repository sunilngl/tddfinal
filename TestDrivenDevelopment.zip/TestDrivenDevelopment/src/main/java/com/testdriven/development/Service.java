package com.testdriven.development;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

@org.springframework.stereotype.Service
public class Service implements IService{

	@Autowired
	IDao Dao;
	
	@Override
	public ModelDTO addModelData(ModelDTO modelDto) {
		
		ModelDTO response = Dao.addModelData(modelDto);
		return response;
	}

	@Override
	public ModelDTO getModelData(Integer modelId) {
		// TODO Auto-generated method stub
		ModelDTO response = Dao.getModelData(modelId); 
		
		return response;
	}

	@Override
	public List<ModelDTO> getAllModelData() {
		
		List<ModelDTO> response = Dao.getAllModelData();
		return response;
	}

	@Override
	public String deleteModelData(Integer modelId) {
		String response = Dao.deleteModelData(modelId);
		return response;
	}

	@Override
	public ModelDTO updateModelData(ModelDTO modelDto) {
		ModelDTO response = Dao.updateModelData(modelDto);
		return response;
	}


}
