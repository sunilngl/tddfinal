package com.testdriven.development;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class Dao implements IDao {

	@Override
	public ModelDTO addModelData(ModelDTO modelDto) {
		ModelDTO response = new ModelDTO();
		response = modelDto;
		
		return response;
	}

	@Override
	public ModelDTO getModelData(Integer modelId) {
		// TODO Auto-generated method stub
		List<ModelDTO> modelList = new ArrayList<ModelDTO>();
		ModelDTO model = new ModelDTO(1,"Sunil","UHG");
		modelList.add(model);
		model = new ModelDTO(2,"Koti","SmartNet");
		modelList.add(model);
		model = new ModelDTO(3,"Ganesh","Global");
		modelList.add(model);
		
		ModelDTO response = null;
		for(ModelDTO dto: modelList) {
			if(dto.getId() == modelId)
				response = dto;
		}
		return response;
	}

	@Override
	public List<ModelDTO> getAllModelData() {
		List<ModelDTO> modelList = new ArrayList<ModelDTO>();
		ModelDTO model = new ModelDTO(1,"Sunil","UHG");
		modelList.add(model);
		model = new ModelDTO(2,"Koti","SmartNet");
		modelList.add(model);
		model = new ModelDTO(3,"Ganesh","Global");
		modelList.add(model);
		return modelList;
	}

	@Override
	public String deleteModelData(Integer modelId) {
		List<ModelDTO> modelList = new ArrayList<ModelDTO>();
		ModelDTO model = new ModelDTO(1,"Sunil","UHG");
		modelList.add(model);
		model = new ModelDTO(2,"Koti","SmartNet");
		modelList.add(model);
		model = new ModelDTO(3,"Ganesh","Global");
		modelList.add(model);
		
		String response = null;
		for(ModelDTO dto: modelList) {
			if(dto.getId() == modelId)
				response = "Record has been deleted";
		}
		return response;
	}

	@Override
	public ModelDTO updateModelData(ModelDTO modelDto) {
		// TODO Auto-generated method stub
		List<ModelDTO> modelList = new ArrayList<ModelDTO>();
		ModelDTO model = new ModelDTO(1,"Sunil","UHG");
		modelList.add(model);
		model = new ModelDTO(2,"Koti","SmartNet");
		modelList.add(model);
		model = new ModelDTO(3,"Ganesh","Global");
		modelList.add(model);
		
		ModelDTO response = null;
		for(ModelDTO dto: modelList) {
			if(dto.getId() == modelDto.getId()) {
				response = modelDto;
				return response;
			}
		}
		return response;
	}

}
