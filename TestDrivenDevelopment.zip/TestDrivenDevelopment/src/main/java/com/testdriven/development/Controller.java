package com.testdriven.development;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

	@Autowired
	IService service;
	
	@PostMapping(path = "/save", consumes = "application/json", produces = "application/json")
	public ModelDTO addData(@RequestBody ModelDTO modelDto) {
		
		//modelDto.setId(1);
		//modelDto.setName("Sunil");
		//modelDto.setCompany("UHG");
		
		ModelDTO response = new ModelDTO();
		response = service.addModelData(modelDto);

		System.out.println(response.getId());
		System.out.println(response.getName());
		System.out.println(response.getCompany());
		return response;
	}
	
	@GetMapping(path = "/getmodel/{id}", produces = "application/json")
	public ModelDTO getModelData(@PathVariable Integer id) {
	
		ModelDTO response = service.getModelData(id);
		
		return response;
	}
	
	@GetMapping(path = "/getall", produces = "application/json")
	public List<ModelDTO> getAllModelData(){
		
		List<ModelDTO> response = service.getAllModelData();
		
		return response;
	}
	
	@DeleteMapping(path = "/delet/{id}", produces = "application/json")
	public String deleteModelData(@PathVariable Integer id) {
	
		String response = service.deleteModelData(id);
		
		return response;
	}
	
	@PostMapping(path = "/update", consumes = "application/json", produces = "application/json")
	public ModelDTO updateModelData(@RequestBody ModelDTO modelDto) {
				
		
		/*
		 * modelDto.setId(1); modelDto.setName("Sunil Nagula");
		 * modelDto.setCompany("UHG");
		 */
		
		
		ModelDTO response = service.updateModelData(modelDto);
		
		return response;
	}
	
}
