package com.testdriven.development;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
class ControllerTests {
	
	@InjectMocks
	Controller controller;
	
	
	@Mock
	IService service;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		System.out.println("Controller Test Started");
	}

	@Test
	void addDataTest() {
		ModelDTO reqeustedData = new ModelDTO();
		reqeustedData.setId(1);
		reqeustedData.setName("Sunil");
		reqeustedData.setCompany("UHG");
		
		
		
		doReturn(reqeustedData).when(service).addModelData(reqeustedData);
		
		ModelDTO actualResponse = service.addModelData(reqeustedData);
		//System.out.println("id is :  "+actualResponse.getId());
		//System.out.println("Name is :  "+actualResponse.getName());
		//System.out.println("Company is : "+actualResponse.getCompany());
		assertThat(actualResponse).isEqualTo(reqeustedData);
		
		
		doThrow(new RuntimeException()).when(service).addModelData(reqeustedData);
		verify(service).addModelData(reqeustedData);
	}

	@Test
	void getModelByIdTest() {
		
		ModelDTO expectedResponse = new ModelDTO();
		expectedResponse.setId(1);
		expectedResponse.setName("Sunil");
		expectedResponse.setCompany("UHG");
		
		
		doReturn(expectedResponse).when(service).getModelData(1);
		
		ModelDTO actualResponse = service.getModelData(1);
		
		assertThat(actualResponse.getId()).isEqualTo(expectedResponse.getId());
		verify(service).getModelData(1);
		
		doThrow(new RuntimeException()).when(service).getModelData(1);
	}
	
	
	@Test
	void getAllModelData() {
		
		List<ModelDTO> modelList = new ArrayList<ModelDTO>();
		ModelDTO model1 = new ModelDTO(1,"Sunil","UHG");
		ModelDTO model2 = new ModelDTO(2,"Koti","SmartNet");
		ModelDTO model3 = new ModelDTO(3,"Ganesh","Global");
		
		modelList.add(model1);
		modelList.add(model2);
		modelList.add(model3);
		
		doReturn(modelList).when(service).getAllModelData();
		
		List<ModelDTO> actualResponse = service.getAllModelData();
		
		assertThat(actualResponse.size()).isEqualTo(modelList.size());
		verify(service).getAllModelData();
		
	}
	
	@Test
	void deleteModelData() {
		
		List<ModelDTO> modelList = new ArrayList<ModelDTO>();
		ModelDTO model1 = new ModelDTO(1,"Sunil","UHG");
		ModelDTO model2 = new ModelDTO(2,"Koti","SmartNet");
		ModelDTO model3 = new ModelDTO(3,"Ganesh","Global");
		
		//modelList.add(model1);
		modelList.add(model2);
		modelList.add(model3);
		String expectedResponse= "Record has been deleted";
		doReturn(expectedResponse).when(service).deleteModelData(1);
		String actualResponse = service.deleteModelData(1);
		assertThat(actualResponse).isEqualTo(expectedResponse);
		verify(service).deleteModelData(1);
	}
	
	@Test
	void updateModelData() {
		
		ModelDTO reqeustedData = new ModelDTO();
		reqeustedData.setId(1);
		reqeustedData.setName("Sunil");
		reqeustedData.setCompany("UHG");
		
		
		
		doReturn(reqeustedData).when(service).updateModelData(reqeustedData);
		
		ModelDTO actualResponse = service.updateModelData(reqeustedData);
		System.out.println("id is :  "+actualResponse.getId());
		System.out.println("Name is :  "+actualResponse.getName());
		System.out.println("Company is : "+actualResponse.getCompany());
		assertThat(actualResponse.getName()).isEqualTo(reqeustedData.getName());
		
		
		doThrow(new RuntimeException()).when(service).addModelData(reqeustedData);
		verify(service).updateModelData(reqeustedData);
	}
	
}
